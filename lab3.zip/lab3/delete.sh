#!/bin/bash
curl -X 'DELETE' 'http://10.1.0.1/board'

